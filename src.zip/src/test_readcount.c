#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  int reset = 0;

  if (argc == 2 && strcmp(argv[1], "reset") == 0)
    reset = 1;

  int count = getreadcount(reset);
  printf(1, "read() has been called %d times\n", count);
  exit();
}
